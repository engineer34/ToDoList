//we are going to import similar as last homework
import "./style.css";
import{
loadApp
} 
from "./domController.js";
loadApp();